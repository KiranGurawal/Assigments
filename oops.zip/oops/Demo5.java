class Demo{
Demo(Demo5 X){
System.out.println("default constructor");
}
}
class Demo5{
void y(){
Demo d = new Demo(this);

}
public static void main(String args[]){
 Demo5 d1 = new Demo5();
 d1.y();

}}