class cons{
  static String name;
  static int id;
/* cons(){
   System.out.println("Default cons..");

}*/

 cons(String name , int id){
  name=name;
  id=id;
   System.out.println(name + " " +id );

   
}
public static void main(String args[])
{
 cons s1 = new cons("kiran",1);
}

}