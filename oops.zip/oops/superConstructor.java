class fruit{
fruit(){
 System.out.println("fruit constructor");
}
}
class superConstructor extends fruit{
superConstructor(){
System.out.println("superConstructor constructor ");
}
public static void main(String args[]){
superConstructor  a = new superConstructor ();
}
}