import java.util.Random; 
abstract class Compartment{
public abstract String notice();
}
class FirstClass extends Compartment{
public String notice(){
return "1 compartment";
}
}
class Ladies extends Compartment{
  public String notice(){
    return "Ladies compartment";
  }
}

class General extends Compartment{
 public String notice(){
    return "General compartment";
  }
}
class Luggage extends Compartment{
     public String notice(){
    return "Luggage compartment";
}
}

class Compartment{
public static void main(String args[]){
TestCompartment[] t = new TestCompartment[10];
Random r = new Random();
for(int i =0; i<10; i++){
int randomNo = r.nextInt((4-1)+1)+1;
if(randomNo == 1)
t[i]= new FirstClass();
else if(randomNo == 2)
t[i]= new Ladies();
else if(randomNo == 3)
t[i]= new General();
else if(randomNo == 4)
t[i]= new Luggage();
System.out.println(t[i].notice());
}
}

}