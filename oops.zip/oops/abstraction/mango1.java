abstract class fruit{
  abstract void color();
}
class apple extends fruit{
void color(){
	System.out.println("apple color red");
}
}
class mango extends fruit{
void color(){
	System.out.println("mango color yello or green");
}
public static void main(String args[]){
 mango c  = mango cat();
 c.eat();
}
}
