abstract class Example{
public abstract void display();
void run(){
System.out.println("noraml method");
}
}
class abstractExample extends Example{
public void display(){
System.out.println("abstract body here");
}
void show(){
System.out.println("method of abstractExample");
}
public static void main(String args[]){
abstractExample s = new abstractExample();
s.show();
s.run();
s.display();
}}