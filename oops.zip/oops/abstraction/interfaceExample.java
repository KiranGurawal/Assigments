interface FirstInterface {
  public void A(); 
}

interface SecondInterface {
  public void B();
}

class DemoClass implements FirstInterface, SecondInterface {
  public void A() {
    System.out.println("interface a");
  }
  public void B() {
    System.out.println("interface b");
  }
}

class interfaceExample {
  public static void main(String[] args) {
    DemoClass myObj = new DemoClass();
    myObj.A();
    myObj.B();
  }
}
 

