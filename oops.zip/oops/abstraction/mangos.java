abstract class fruit{
  abstract void color();
}
class apple extends fruit{
void color(){
	System.out.println("apple color red");
}
}
class mangos extends fruit{
void color(){
	System.out.println("mango color yello or green");
}
public static void main(String args[]){
 mangos c  = new mangos();
 c.color();
}
}
