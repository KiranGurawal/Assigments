abstract class GeneralBank{
abstract int getSavingsInterestRate();
abstract double getFixedDepositInterestRate();

}
 class ICICIBank extends GeneralBank{
int getSavingsInterestRate(){
 return 4;
}
double getFixedDepositInterestRate(){
 return 8.5;
}

}
class SBIBank extends GeneralBank{
int getSavingsInterestRate(){
 return 4;
}
double getFixedDepositInterestRate(){
 return 7;
}
}

class abstractAssigment1{
public static void main(String args[]){
ICICIBank i = new ICICIBank();
System.out.println("saving interest"+ i.getSavingsInterestRate()+"%  " +"fixed deposit" + i.getFixedDepositInterestRate()+"%");
SBIBank s = new SBIBank();
System.out.println("saving interest"+ s.getSavingsInterestRate()+"%  "+ "fixed deposit" + s.getFixedDepositInterestRate()+"%");
//GeneralBank g = new GeneralBank();  (abstract class cannot be create object)
}


}