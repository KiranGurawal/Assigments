import java.util.Scanner;
interface LibraryUser{
void registerAccount();
void requestBook();
}
class KidUser implements LibraryUser{
int age;
String BookType ="";
String Book1 = "kid";
public void registerAccount(){
if(age<12){
System.out.println("you have Successfully registered under a kids account");
}
else{
System.out.println("Sorry, Age must be less than 12 to register as a kid");
}
}
public void requestBook(){
if(BookType.equals(Book1)){
System.out.println("Book issued successfully,Please return the book within 10 days");
}
else{
System.out.println("Oops, you are allowed to take only kids books");
}

}

}


class AdultUser implements LibraryUser{
int age;
String BookType;	
public void registerAccount(){
	
if(age>12){
System.out.println("you have Successfully registered under an Adult account");
}
else{
System.out.println("Sorry, Age must be greater than 12 to register as a Adult");
}
}
public void requestBook(){
if(BookType.equals("fiction")){
System.out.println("Book issued successfully,Please return the book within 10 days");
}
else{
System.out.println("Oops, you are allowed to take only adult fiction books");
}


}
}   
class LibraryInterfaceDemo{
public static void main(String args[]){
	Scanner s = new Scanner(System.in);
System.out.println("Enter age:");
int age = s.nextInt();

KidUser kid = new KidUser();
System.out.println("Enter Booktype:");
s.nextLine();
//KidUser.BookType = s.nextLine();


kid.registerAccount();
kid.requestBook();
}
}


