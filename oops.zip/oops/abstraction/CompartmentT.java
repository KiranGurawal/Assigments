import java.util.Random; 
abstract class Compartment{
public abstract String notice();
}
class FirstClass extends Compartment{
public String notice(){
return "1 compartment";
}
}
class Ladies extends Compartment{
  public String notice(){
    return "Ladies compartment";
  }
}

class General extends Compartment{
 public String notice(){
    return "General compartment";
  }
}
class Luggage extends Compartment{
     public String notice(){
    return "Luggage compartment";
}
}

class CompartmentT{
        public static void main(String args[]){
         Compartment[] T=new Compartment[10];
          Random random=new Random();
       for (int i = 0; i < 10; i++) 
         {
		    int randnum=random.nextInt((4-1)+1)+1;
			if(randnum == 1)
			T[i]= new FirstClass();
			else if(randnum==2)
			T[i]= new Ladies();
			else if(randnum==3)
			T[i]= new General();
			else if(randnum==4)
			T[i]= new Luggage();
			
			System.out.println(T[i].notice());
			
		 }
			
		 }	   

}