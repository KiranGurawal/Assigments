class Person{
String name;
String dateOfBirth;
Person(String name, String dateOfBirth){
this.name = name;
this.dateOfBirth = dateOfBirth;
}
}
class Teacher extends Person{
double salary;
String subject;
Teacher(double salary,String subject,String name, String dateOfBirth){
super(name,dateOfBirth);
this.subject=subject;
this.salary=salary;
}
}
}
class Student extends Person{
int studentid;
studentid(int studentid,String name, String dateOfBirth){
 super(name,dateOfBirth);
 this.studentid = studentid;
}
}
class College extends Student{
String collegeName;
String year; 
College(int studentid,String name, String dateOfBirth, String collegeName, String year ){
super(name,dateOfBirth,studentid);
this.year = year;
this.collegeName = collegeName;
}
}
class inheritance1{
public static void main(String args[]){
Student s =new Student();
student.setname("kiran");
student.setdateOfBirth("25-01-2000");
student.setstudentid(101);
student.setcollegeName("IET-DAVV");
student.setyear(4);
System.out.println("Student Name: "+student.getName());
System.out.println("Student Dob: "+student.getDob());
System.out.println("Student ID: "+student.getStudentId());
System.out.println("College Name: "+student.getCollegeName());
System.out.println("College Year: "+student.getYear()+" Year");
		
}