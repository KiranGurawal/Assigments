class Demo3{
 Demo3(){
   System.out.println("Default constructor");
}
 Demo3(int a){
   this();
  System.out.println("parameter constructor");
}
public static void main(String args[]){
  Demo3 d = new Demo3();
}

}