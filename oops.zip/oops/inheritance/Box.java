class Box{
Box(int length, int breath, int height){
  int volume= length*breath*height;
  System.out.println(volume);

}
public static void main(String args[]){
Box b1 = new Box(12,3,4);
}

}