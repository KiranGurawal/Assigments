class Tree{
void color(){
System.out.println("mango color is yellow");
}

}
class mango extends Tree{
void taste(){
System.out.println("mango has sharp taste");
}
public static void main(String args[]){
//Tree t1 = new Tree();
//t1.color();
mango m= new mango();
m.taste();
m.color();		


}



}