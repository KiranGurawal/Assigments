interface A{
public void dancing();
}
interface B{
public void singing();
}

 class multipleInheritance implements A,B{
public void dancing(){
System.out.println("i am dancing");
}
public void singing(){
System.out.println("i am singing");
}

public static void main(String args[]){
 multipleInheritance m = new multipleInheritance();
 m.singing();
m.dancing();
}



}