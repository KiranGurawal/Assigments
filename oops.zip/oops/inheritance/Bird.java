class Animal{
	void eat(){
System.out.println("Animal eating");

}
	void sleep(){
System.out.println("Animal sleeping");
}

}
class Bird extends Animal{
	void fly(){
System.out.println("Birds flying");
}

	void eat(){
System.out.println("Birds eating");
}
	void sleep(){
System.out.println("Birds sleeping");
}

public static void main(String args[]){
 Bird B = new Bird();
 B.fly();
 B.eat();
 B.sleep();
/* Animal A = new Animal();
 A.fly();
 A.eat();
 A.sleep();*/


}


}