class Person
{
private String name;
private String dob;
	
void setName(String name)
{
this.name=name;
}
String getName()
{
return name;
}
void setDob(String dob)
{
this.dob=dob;
}
	
String getDob()
{
return dob;
}
}

class Teacher extends Person
{
private int salary;
private String subject;
void setSalary(int salary)
{
this.salary=salary;
}
int getSalary()
{
return salary;
}
void setSubject(String subject)
{
this.subject=subject;
}
String getSubject()
{
return subject;
}
}

class Student extends Person
{
	int studentId;
	
	void setStudentId(int studentId)
	{
		this.studentId=studentId;
	}
	
	int getStudentId()
	{
		return studentId;
	}
}

class CollegeStudent extends Student
{
	String collegeName;
	int year;
	
	void setCollegeName(String collegeName)
	{
		this.collegeName=collegeName;
	}
	
String getCollegeName()
{
return collegeName;
}
	
void setYear(int year)
{
this.year=year;
}
	
int getYear()
{
return year;
}
}

class inheritance1
{
public static void main(String [] args)
{
CollegeStudent student=new CollegeStudent();
student.setName("kiran");
student.setDob("25-01-2000");
student.setStudentId(106);
student.setCollegeName("IET-DAVV");
student.setYear(4);
System.out.println("Student Name: "+student.getName());
System.out.println("Student Dob: "+student.getDob());
System.out.println("Student ID: "+student.getStudentId());
System.out.println("College Name: "+student.getCollegeName());
System.out.println("College Year: "+student.getYear()+" Year");
		
		
}}