class a{
void show(){
System.out.println("it is show method in A class");
}

}
class b extends a{
int show(){
System.out.println("it is show method in B class");
}

public static void main(String args[]){
 b b1 = new b();
 b1.show();

}

}