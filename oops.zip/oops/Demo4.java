class Demo4{
void eat(Demo4 d){
System.out.println("i am eating");
}
void fly(){
eat(this);
}
public static void main(String args[]){

Demo4 d1 = new Demo4();
//d1.eat();
d1.fly();
}

}