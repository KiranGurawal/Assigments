class Demo2{
 void display(){
   System.out.println("dispaly method");
}
 void show(){
   //System.out.println("show method");
   this.display();

}
public static void main(String args[]){
 Demo2 d = new Demo2();
 d.show();
}



}