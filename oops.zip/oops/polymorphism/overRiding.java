class fruit{
String name;
String taste;
String size;
void eat(){
name = "Banana";
taste = "Sweet";
size = "Small";
System.out.println("name is" +name+ "taste" +taste+ " and Size is" +size);
}
}
class Apple extends fruit{
void eat(){
name = "Apple";
taste = "Sweet";
size = "Small";
System.out.println("name is" +name+ "taste" +taste+ " and Size is" +size);
}
}
class orange extends fruit{
void eat(){
name = "orange";
taste = "citrus";
size = "large";
System.out.println("name is" +name+ "taste" +taste+ " and Size is" +size);
}
}
class overRiding{
public static void main(String args[]){
Apple a = new Apple();
a.eat();
orange o = new orange();
o.eat();
}

}