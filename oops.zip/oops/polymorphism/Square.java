class shape{
void draw(){
System.out.println("drawing Shape");
}
void erase(){
System.out.println("Erasing Shape");
}
}

class Circle extends shape{
void draw(){
System.out.println("drawing Circle");
}
void erase(){
System.out.println("Erasing Circle");
}

}
class Triangle extends shape{
void draw(){
System.out.println("drawing Triangle");
}
void erase(){
System.out.println("Erasing Triangle");
}

}
 class Square extends shape{
 void draw(){
System.out.println("drawing Square");
}
void erase(){
System.out.println("Erasing Square");
}
 public static void main(String args[]){
shape c = new Circle();
c.draw();
c.erase();
shape t = new Triangle();
t.erase();
t.draw();
shape s = new Square();
s.erase();
t.draw();
 }}