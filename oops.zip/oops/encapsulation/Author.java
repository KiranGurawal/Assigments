class Author{
private String name;
private String email;
private char gender;
Author(String name,String email,Char gender){
 this.name =name;
 this.email =email;
 this.gender= gender;

}

public String getName(){
  return name;
}
public String getEmail(){
    return email;
}
public char getGender(){
    return gender;
}
}
class Book
{
	private String bookName;
	private Author author;
	private double price;
	private int qtyInStock;
	
	Book(String name, Author author, double price, int qtyInStock)
	{
		this.bookName=name;
		this.author=author;
		this.price=price;
		this.qtyInStock=qtyInStock;
	}
	
	String getBookName()
	{
		return bookName;
	}
	
	double getPrice()
	{
		return price;
	}
	
	int getQtyInStock()
	{
		return qtyInStock;
	}
	
	public static void main(String [] args)
	{
		
		Book book=new Book("Mathematics",new Author("abc","abc@gmail.com",'M'),200.0,30;
		
		System.out.println("Book name: "+book.getBookName());
		System.out.println("Book Price: "+book.getPrice());
		System.out.println("Book Quantity: "+book.getQtyInStock());
		System.out.println("Author Name: "+book.author.getName());
		System.out.println("Author Email: "+book.author.getEmail());
		System.out.println("Author Gender: "+book.author.getGender());
		
	}
}