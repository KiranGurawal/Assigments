class Example{
int a = 100;
}
class superVariable extends Example{
int a = 300;
void show(int a){
System.out.println(a);
System.out.println(this.a);
System.out.println(super.a);
}


public static void main(String args[]){
superVariable s1 = new superVariable();
s1.show(10);

}
}