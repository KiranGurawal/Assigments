class mobile{
 void rining(){
   System.out.println("mobile is ringing");
}

}
class Phone extends mobile{
 void rining(){
  System.out.println("Phone is rining"); 
}
 void vibrate(){
 super.rining();
  System.out.println("Phone is vibrating");
 }
public static void main(String args[]){
Phone p = new Phone();
//p.rining();
p.vibrate();
}


} 