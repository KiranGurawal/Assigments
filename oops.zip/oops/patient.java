class patient{
String patientName = "kiran";
double computerBMI(double height, int weigth){
double BMI = weigth/height*height;
return BMI;
}

public static void main(String args[]){
 patient p =new patient();
  System.out.println(p.computerBMI(6.5,40));
 
}


}