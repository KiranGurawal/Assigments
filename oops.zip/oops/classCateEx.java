class object {
object(int a){
System.out.print("hello");
}
}
class classCateEx{
public static void mian(String args[]){
 object obj = new Integer(200);
System.out.println((String) obj);
}
}