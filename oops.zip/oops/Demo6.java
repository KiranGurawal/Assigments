class Demo{
int a=10;
int display(){
return this.a;

}
}

class Demo6{
public static void main(String args[] ){

Demo d = new Demo();
System.out.println(d.display());
}

}