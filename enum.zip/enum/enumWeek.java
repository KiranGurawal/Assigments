class enumWeek{
enum Week{
	SUN,MON,TUES,WEND,THUR,FRI,SAT;
	}
	public static void main(String args[]){
	for(Week d:Week.values())
	{
	System.out.println(d);
	}
	Week w;
	w = MON;
	switch(w){
	case SUN:
	System.out.println("Today "+Week.valueOf("SUN")+ "Index is "+Week.valueOf("SUN").ordinal());
	break;
	case MON:
	System.out.println("Today "+Week.valueOf("MON")+ "Index is "+Week.valueOf("MON").ordinal());
	
	break;
	case FRI:
	System.out.println("Today "+Week.valueOf("TUES")+ "Index is "+Week.valueOf("TUES").ordinal());
	
	break;
	case TUES:
	System.out.println("Today "+Week.valueOf("TUES")+ "Index is "+Week.valueOf("TUES").ordinal());
	
	break;
	case WEND:
	System.out.println("Today "+Week.valueOf("MON")+ "Index is "+Week.valueOf("MON").ordinal());
	break;
	case MON:
	System.out.println("Today "+Week.valueOf("MON")+ "Index is "+Week.valueOf("MON").ordinal());
	
	default:
	System.out.println("NOT A WEEKDAY");
}

}
}