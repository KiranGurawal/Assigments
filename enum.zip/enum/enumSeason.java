class enumSeason{
enum Season{SUMMER(1),WINTER(2), RAINY(3), SPRING(4);
int ses;
Season(int ses){
	this.ses=ses;
}
}
	public static void main(String args[]){
		for(Season d:Season.values())
{
		System.out.println(d+ " "+d.ses);
}
	Season s;
	s=Season.SUMMER;
	switch(s){
	case SUMMER:
	System.out.println("Season is:"+Season.valueOf("SUMMER")+ "Index is "+Seasons.valuesOf("SUMMER").ordinal());
	break;
	case WINTER:
	System.out.println("Season is:"+Season.valueOf("WINTER")+ "Index is "+Seasons.valuesOf("WINTER").ordinal());
	break;
	case RAINY:
	System.out.println("Season is:"+Season.valueOf("RAINY")+ "Index is "+Seasons.valuesOf("RAINY").ordinal());
	break;
	case SPRING
	System.out.println("Season is:"+Season.valueOf("SPRING")+ "Index is "+Seasons.valuesOf("SPRING").ordinal());
	break;
	default:
	System.out.println("Sorry........");
	
}
}
}