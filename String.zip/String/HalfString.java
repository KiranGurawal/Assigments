import java.util.Scanner;
class HalfString{
public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        system.out.println("Enter the String:");
        String s1 = scan.nextLine();
        int x = s1.length();
        System.out.println(s1.substring(0, x/2)); 
}
}