import java.util.Scanner;
class FirstLastcharRemove{
public static void main(String args[]){
Scanner s1= new Scanner(System.in);
System.out.println("Enter the string value:");
String s2 = s1.nextLine();
System.out.println(s2.substring(1,s2.length() - 1));
}
}

