class stringEqual{
public static void main(String args[]){
String s1 = "this is String comparing programe";
String s2 ="hello string";
String s3 = "this is String comparing programe";
//System.out.println(s1.equals(s2));
System.out.println(s1.equals(s3));


}

}