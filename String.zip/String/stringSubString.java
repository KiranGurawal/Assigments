class stringSubString{
public static void main(String args[]){ 
String s1="kirangurawal";  
//System.out.println(s1.substring(3,5)); 
System.out.println(s1.substring(5));
}}  


