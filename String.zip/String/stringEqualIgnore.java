class stringEqualIgnore{
public static void main(String args[])
{
String s1="kiran";  
String s2="kiran gurawal";  
String s3="kiran";  
String s4="KIRAN GURAWAL";  
//System.out.println(s1.equalsIgnoreCase(s2));
System.out.println(s1.equalsIgnoreCase(s3));
}}  