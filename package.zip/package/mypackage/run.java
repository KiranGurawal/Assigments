package mypackage;
public class run{
	public void show(){
		System.out.println("i am show method of run class ");
	}
}