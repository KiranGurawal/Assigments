package mypackage;
class start{
	public void display(){
		System.out.println("i am start");
	}	

}