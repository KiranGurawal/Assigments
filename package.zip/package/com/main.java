import TestPackage.foundation;
 public class main{
public static void main(String args[]){
foundation f = new foundation();
//System.out.println(f.var1);
//System.out.println(f.var2);
//System.out.println(f.var3);
System.out.println(f.var4);
}

}