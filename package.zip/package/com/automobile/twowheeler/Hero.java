package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Hero extends Vehicle{
    public void radio(){
        System.out.println("Radio");
    }
    public int getSpeed()
    {
        return 100;
    }
    public String getModelName(){
        return "HERO";
    }
    public String getregistrationNumber(){
        return "2345";
    }
    public String getOwnerName(){
        return "Kiran";
    }
    

}