package com.automobile;
abstract class Vehicle{
public string getModeName();
public String getregistrationNumber();
public String getOwnerName();
}