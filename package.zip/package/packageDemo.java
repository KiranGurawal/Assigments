import mypackage.run;
class packageDemo{
	public static void main(String args[]){
		run ob = new run();
		ob.show();
}}