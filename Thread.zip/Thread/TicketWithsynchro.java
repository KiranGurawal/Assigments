class BookTicket{
int totalseats=12;
synchronized void bookSeat(int sets){
synchronized(this){
if(totalseats >= seats){
System.out.println("Booked sucessfully");
totalseats = totalseats-seats;
system.out.println("Remaing seats"+totalseats);
}
else{
System.out.println("Seats are not avilable:"+ totalseats);
}
}
}
}
public class TicketWithsynchro extends Thread{

static BookTicket b;
int seats;
public void run(){
	b.bookSeats(seats);
}
public static void main(String args[]){
BookTicket b= new Bookticket();
Thread1 t1 = new Thread1(b,8);
t1.start();
Thread2 t2 = new Thread2(b1,3);
t2.start();

}
}