class ThreadSleepDemo extends Thread
{
 public static void main(String[] args)
 {
	 try
	 {
		 for(int i = 0;i<=3;i++)
		 {
			 Thread.sleep(4000);
			 System.out.println(i);
		 }
	 }	
     catch (Exception e)
     {e.printStackTrace();}	 
 }
}