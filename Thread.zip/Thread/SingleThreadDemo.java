public class SingleThreadDemo extends Thread{
public void run(){
System.out.println("thread started");
}
public static void main(String args[]){
SingleThreadDemo td = new SingleThreadDemo();
td.start();
td.star();
}

}