class ThreadNameDemo extends Thread
{
  public void run()
  {
	  Thread.currentThread().setName("RUN");
	  System.out.println("Run:" + Thread.currentThread().getName());
	  
  }
  public static void main(String[]args)
  {
	  ThreadNameDemo t = new ThreadNameDemo();
	  t.setName("T1 Thread");
	  t.start();
	  
	   ThreadNameDemo t1 = new ThreadNameDemo();
	  t1.setName("T2 Thread");
	  t1.start();
	  
  }
}