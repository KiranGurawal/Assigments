public class ThreadDemo extends Thread{
public void run(){
System.out.println("thread started");
}
public static void main(String args[]){
ThreadDemo td = new ThreadDemo();
ThreadDemo t = new ThreadDemo();
td.start();
t.start();

}

}