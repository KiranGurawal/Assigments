import java.io.IOException;
class Revenue extends Thread
{
int total=0;
public void run(){
    synchronized(this){
	for(int i=1;i<=5;i++)
	{
		total=total+400;
	}
	this.notifyAll(); 
                       }
}
public void run(){
    synchronized(this){
	for(int i=1;i<=5;i++)
	{
		total=total+400;
	}
	this.notifyAll(); 

}
public class ThreadInterProcessDemo2{
	public static void main(String args[]) throws Exception
	{
		Revenue r = new Revenue();
		r.start();
		//System.out.println("Total amount" + r.total);
		synchronized(r)
	{
		r.wait();
		System.out.println("Total Amount" + r.total);
	}
	}
}