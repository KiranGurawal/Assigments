class ThreadisAliveDemo extends Thread
{
 public void run()
  {
	  Thread.currentThread().setName("RUN");
	  System.out.println("Run:" + Thread.currentThread().getName());
	  
  }
  public static void main(String[]args)
  {
	  System.out.println(Thread.currentThread().getName());
	  ThreadisAliveDemo t = new ThreadisAliveDemo();
	  System.out.println(t.isAlive());
	  t.setName("T1 Thread");
	  t.start();
	  System.out.println(t.isAlive());
	  
	  ThreadisAliveDemo t1 = new ThreadisAliveDemo();
	  t1.setName("T2 Thread");
	  t1.start();
	  
  }
}
