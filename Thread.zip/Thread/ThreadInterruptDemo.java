class ThreadInterruptDemo extends Thread{
public void run(){
System.out.println(Thread.interrupted());
try{
for(int i =1;i<=3;i++){
System.out.println(i);
Thread.sleep(1000);
}}
catch(Exception e){
System.out.println(e);
}
}
public static void main(String args[]){
ThreadInterruptDemo t = new ThreadInterruptDemo();
t.start();
t.interrupt();
}
}