class MyThread1 extends Thread{
public void run(){
System.out.println("thread1 started");
}

}
class MyThread2 extends Thread{
public void run(){
System.out.println("thread2 started");
}

}

class MyThread3 extends Thread{
public void run(){
System.out.println("thread3 started");
}

}



public class MultipleThreadDemo2 extends Thread{
public void run(){
System.out.println("thread started");
}
public static void main(String args[]){
MyThread1 t = new MyThread1();
t.Start();
MyThread1 t1 = new MyThread1();
t1.Start();
MyThread1 t2 = new MyThread1();
t2.Start();

}

}