class RunnableInterfaceDemo implements Runnable{
public void run(){
System.out.println("Started Thread using runable interface");
}
public static void main(String args[]){
Thread t = new Thread(new RunnableInterfaceDemo());
t.start();
}

}