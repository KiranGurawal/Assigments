class ThreadPriorityDemo extends Thread
{
  public void run()
  {
  System.out.println("In run Method");
  System.out.println(Thread.currentThread().getPriority());
  }
  
  public static void main(String[] args)
  {
	 System.out.println(Thread.currentThread().getPriority()); 
	 Thread.currentThread().setPriority(MIN_PRIORITY);
	 System.out.println(Thread.currentThread().getPriority());
	 ThreadPriorityDemo t = new ThreadPriorityDemo();
	 t.start();
	 
  }
}