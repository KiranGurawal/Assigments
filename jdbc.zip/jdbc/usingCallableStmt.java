import java.sql.*;
class usingCallableStmt{
public static void main(String args[]){
try{
Class.forName("com.mysql.jdbc.Driver");
String url ="jdbc:mysql://localhost:3306/yash";
String user ="root";
String pass ="root";
Connection con = DriverManager.getConnection(url,user,pass);
String q = "insert into emp values(?,?)";
CallableStatement c = con.prepareCall(q);
BufferedReader d = new BufferedReader(new InputStreamReader(System.in));
System.out.println("Enter user id");
int ID = d.readLine();

c.setString(2,"pratik");
c.execute();
System.out.println("done");

}
catch(Exception e){
e.printStackTrace();

}

}
}