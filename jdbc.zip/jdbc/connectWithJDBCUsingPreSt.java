import java.sql.*;
class connectWithJDBCUsingPreSt{
	public static void main(String args[])
	{
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
			String url ="jdbc:mysql://localhost:3306/yash";
			String user ="root";
			String password = "root";
			Connection con = DriverManager.getConnection(url,user,password);
			PreparedStatement s = con.prepareStatement("insert into emp values(?,?)");
				s.setInt(1,104);
				s.setString(2,"riya");
			int i = s.executeUpdate();
			System.out.println(i+"show insert data");
		   
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}