import java.io.*;
import java.sql.*;
public class ImageStore{
public static void main(String args[]){
try{
Class.forName("com.mysql.jdbc.Driver");
String url ="jdbc:mysql://localhost:3306/yash";
String user = "root";
String pass = "root";
Connection con = DriverManager.getConnection(url,user,pass);
PreparedStatement p = con.prepareStatement("insert into img values(?)"); 

FileInputStream f = new FileInputStream("d:\\flower.jfif");
p.setBinaryStream(1,f,f.available());
int i = p.executeUpdate();
System.out.println("inserted");
con.close();
}
catch(Exception e){
e.printStackTrace();
}
}
}