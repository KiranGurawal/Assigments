import java.awt.event.*;  
import javax.swing.*;    
public class swing {  
public static void main(String[] args) {  
    JFrame f=new JFrame("swing");  
    final JTextField t=new JTextField();  
    t.setBounds(50,50, 150,20);  
    JButton b=new JButton("Click Here");  
    b.setBounds(50,100,95,30);  
    b.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
            t.setText("Welcome to Javatpoint.");  
        }  
    });  
    f.add(b);f.add(t);  
    f.setSize(400,400);  
    f.setLayout(null);  
    f.setVisible(true);   
    f.setdefault closeOperation(Jframe.EXIT_ON_CLOSE);
}  
}  
