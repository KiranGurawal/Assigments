import java.sql.*;
class connectionDemo{
public static void main(String args[]){
try{
Class.forName("com.mysql.jdbc.Driver");
String user="root";
String pass="root";
String url = "jdbc:mysql://localhost:3306/yash";
Connection con = DriverManager.getConnection(url,user,pass);
Statement s = con.createStatement();
ResultSet set = s.executeQuery("Select * from emp");
while(set.next()){
int ID = set.getInt("ID");
String name = set.getString("name");
System.out.println("Employee ID:" + ID);
System.out.println("Employee Name:" + name);
}

con.close();
}
catch(Exception e){
e.printStackTrace();
}
}




}