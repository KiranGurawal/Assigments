import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.IOException; 
class Employee implements Serializable
 {
	int id;
	String name;
	float salary;
	long contactNo;
	String emailID;
	
    public Employee(int id,String name,float salary,long contactNo,String emailID)
    {
    	this.id=id;
    	this.name=name;
    	this.salary = salary;
    	this.contactNo = contactNo;
    	this.emailID = emailID;	
    }
    public String toString() 
    {
    	return "ID:" +this.id + "\n Name:" +this.name + "\n Salary"+this.salary +"\n ContactNo"+this.contactNo +"\n Email ID:"+this.emailID;
    }
 }
public class EmployeeManagement 
{
	static void display(ArrayList<Employee> a)
	{
		System.out.println("---------------------------");
		System.out.println("Enter Employee ID,Name,Salary,Contact,Email");
		for(Employee e:a) 
		{
			System.out.println(String.format("%-5s%-20s%-10s%-15s%-10s",e.id,e.name,e.salary,e.contactNo,e.emailID));
		}
	}
	
	public static void main(String args[])throws IOException
	{
		int id=0;
		String name;
		float salary;
		long contactNo;
		String emailID;         
		ArrayList<Employee> a= new ArrayList<Employee>();
		File f = null;
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		BufferedReader d = new BufferedReader(new InputStreamReader(System.in));


		try 
		{
		    f = new File("D:\\employee.txt");
			if(f.exists())
			{
			     fis = new FileInputStream(f);
				 ois = new ObjectInputStream(fis);
				 a = (ArrayList<Employee>)ois.readObject();
			}
		}
		catch(Exception e) 
		{
		  e.printStackTrace();	
		}
		do {
			 System.out.println("----------------");
			 System.out.println("1. Add Employee :");
			 System.out.println("2. Search Employee");
			 System.out.println("3. Edit Employee list:");
			 System.out.println("4. Delete Employee list");
			 System.out.println("5. Display all Employee list");
			 System.out.println("6. Exit");
			 System.out.println("Enter your choice");
			 int choice = d.read();
			 switch(choice)
			 {
			 case 1:System.out.println("Enter following details");
			        System.out.println("Enter ID:");
			        id = d.read();
			        System.out.println("Enter Name:");
			        name=d.readLine();
			        System.out.println("Enter salary:");
			        salary = d.read();
			        System.out.println("Enter Contact no:");
			        contactNo = d.read();
			        System.out.println("Enter Email ID");
			        emailID =d.readLine();
			        a.add(new Employee(id,name,salary,contactNo,emailID));
			        display(a);
			        break;
			 case 2:System.out.println("Enter the Employee Id to search:");
			        id = d.read();
			        int i=0;
			        for(Employee e :a)
			        {
			        	if(id == e.id)
			        	{
			        		System.out.println(e);
			        		i++;
			        	}
			        }
			        if(i == 0)
			        {
			        	System.out.println("Please enter a valid employee ID");
			        }
				    break;
			 case 3:System.out.println("Enter the employee Id to Edit the list");
			        d.read();
			        int j = 0;
			        for(Employee e:a)
			        {
			        	if(id==e.id) {
			        		j++;
			        		do {
			        			int c1 = 0;
			        			System.out.println("Employee Details: ");
			        			System.out.println("1) Employee ID");
			        			System.out.println("2) Name");
			        			System.out.println("3) salary");
			        			System.out.println("4) Contact no");
			        			System.out.println("5) Email");
			        			System.out.println("6) Go to back");
			        			System.out.println("Enter choice:");
			        			c1 =d.read();
			        			
			        	switch(c1)
			        	{
			        	case 1: 
			        		  System.out.println("Enter new Employee id");
			        	      e.id = d.read();
			        	      System.out.println(e);
			        	      break;
			        	case 2:      
			        	      System.out.println("Enter new Name");
			        	      e.name = d.readLine();
			                  System.out.println(e);
			                  break;
			        	case 3:      
			                  System.out.println("Edit salary");
			                  e.salary = d.read();
			                  System.out.println(e);
			                  break;
			        	case 4:      
			                  System.out.println("Edit contact no");
			                  e.contactNo = d.read();
			                  System.out.println(e);
			                  break;
			        	case 5:
			        		  System.out.println("Edit email id");
			        		  e.emailID = d.readLine();
			        		  System.out.println(e);
			        		  break;
			        	case 6: 
			        		 j++;
			        		 break;
			        	default:
			        		  System.out.println("invalid");
			        		  break;
			        	}		
			        	}
			        		while(j==1);
			        	}
			        }
			        if(j==0) {
			        	System.out.println("Please enter valid id");
			        }
			        break;
			        
			 case 4:System.out.println("Enter employee id to delete from the list:");
			        id = d.read();
			        int k = 0;
			        try
			        {
			        	for(Employee e : a)
			        	{
			        		if(id == e.id)
			        		{
			        			a.remove(e);
			        			display(a);
			        			k++;
			        		}
			        	}
			        	if(k == 0)
			        	{
			        		System.out.println("please enter a valid id");
			        	}
			        }
			        catch(Exception e) {
			        	e.printStackTrace();
			        }
			   break;
			   
			 case 5:try {
				a = (ArrayList<Employee>)ois.readObject();  
			 }
			 catch(ClassNotFoundException e1) {
				 e1.printStackTrace();
	 		                                 }
			 
			 catch(Exception e){
				 e.printStackTrace();
			 }
			 
			 display(a);
			 break;
			 
			 case 6:try {
				 fos = new FileOutputStream(f);
				 oos = new ObjectOutputStream(fos);
				 oos.writeObject(a);
				
		     }
			 catch(Exception e) {
				 System.out.println(e);
			  }
			 finally {
				 try {
					 fis.close();
					 ois.close();
					 fos.close();
					 oos.close();
				 }
				 catch(Exception e) {
					 e.printStackTrace();
				 }
			 }
			 System.out.println("You have chose exit");
			 d.close();
			 System.exit(0);
			 break;
			 
			 default:System.out.println("Enter a correct choice");
			 break;
				 
			 }

		}				while(true);

			 
			 
			 }

		   }


