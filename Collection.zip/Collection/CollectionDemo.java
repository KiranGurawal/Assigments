import java.util.ArrayList;
import java.util.Iterator;
public class CollectionDemo{
public static void main(String args[]){
ArrayList<String> a1 = new arrayList<String>();
a1.add();
a1.add();
Iterator j = a1.iterator();
while(i.hasNext());
{
for(String i:a1){
System.out.println("For Each +i");
}
System.out.println("get element  index1" + a1.get(1));
a1.set(2,"kiran");
for(String j:a1){
System.out.println(j);
}
}
Collection.sort(a1);
for(String j : a1){
System.out.println(j);
}}
}