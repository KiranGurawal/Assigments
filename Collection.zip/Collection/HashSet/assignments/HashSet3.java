import java.util.TreeSet;
import java.util.Iterator;
class HashSet3
{
	public static void main(String[] args)
	{
		TreeSet<String> t=new TreeSet<String>();
		t.add("Welcome");
		t.add("to");
		t.add("Yash");
		t.add("Technologies");
		System.out.println(t);
		Iterator i=t.iterator();
		System.out.println("Iterated through iterator: ");
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		System.out.println(t.contains("Yash"));
	}
}