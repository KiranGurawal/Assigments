import java.util.Properties;
import java.util.Iterator;
import java.util.Set;
class HashMap2
{
	public static void main(String[] args)
	{
		Properties capitals=new Properties();
		Set state;
		String s;
		capitals.put("MadhyaPradesh","Bhopal");
		capitals.put("UttarPradesh","Bihar");
		capitals.put("Goa","Panji");
		capitals.put("Maharshtra", "Mumbai");
		state=capitals.keySet();
		Iterator i=state.iterator();
		while(i.hasNext())
		{
			s=(String)i.next();
			System.out.println("Capital of:" +s+" is "+capitals.getProperty(s));
		}
	}
}