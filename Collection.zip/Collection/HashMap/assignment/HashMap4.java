import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
class CountryCapital
{  
    HashMap<String, String> M1=new HashMap<String, String>();
	HashMap<String, String> M2=new HashMap<String, String>();
	String saveCountryCapital(String Countryname, String capital)
	{
		M1.put(Countryname,capital);
		Iterator<Map.Entry<String, String>>i=M1.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String>en=i.next();
			System.out.println("Country: "+en.getKey()+" Capital: "+en.getValue());
		}
		return Countryname+ " "+capital;
	}
	String getCapital(String Countryname)
	{
		Iterator<Map.Entry<String, String>>i=M1.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String>en=i.next();
			if(Countryname ==en.getKey())
			{
				System.out.println(en.getValue());
				break;
			}
		}
		return Countryname;
	}
	String getCountry(String capital)
	{
		Iterator<Map.Entry<String, String>>i=M1.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String>en=i.next();
			if(capital ==en.getValue())
			{
				System.out.println(en.getKey());
				break;
			}
		}
		return capital;
	}
	void swap()
	{
		Iterator<Map.Entry<String,String>>i=M1.entrySet().iterator();
		while(i.hasNext())
		{
			Map.Entry<String,String>en=i.next();
			String key=en.getValue();
			String value=en.getKey();
			M2.put(key,value);
		}System.out.println(M2);
	}
}
class HashMap4{
	public static void main(String[] args)
	{
		CountryCapital c=new CountryCapital();
		c.saveCountryCapital("India","Delhi");
		c.saveCountryCapital("Japan","Tokyo");
		c.getCapital("India");
	    c.getCountry("Tokyo");
		c.swap();
	}
}