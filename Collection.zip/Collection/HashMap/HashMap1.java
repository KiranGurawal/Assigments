import java.util.HashMap;
import java.util.Iterator;
class HashMap1
{
	public static void main(String[] args)
	{
		HashMap<Integer,String> h=new HashMap<Integer,String>();
		h.put(1,"We");
		h.put(2,"are");
		h.put(3,"happy");
		h.put(4,"faces");
		System.out.println(h.containsValue("happy"));
		System.out.println(h.containsKey(5));
		Iterator it=h.keySet().iterator();
		while(it.hasNext())
		{
			int key=(int)it.next();
			System.out.println(key+" "+h.get(key));
		}
	}
}