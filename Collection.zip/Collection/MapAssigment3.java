import java.util.Map;
import java.util.HashMap;
class MapAssigment3{
public static void main(String args[]){
Map<Integer,String> map = new HashMap<Integer,String>();
map.put(19992,"kiran");
map.put(32767,"neha");
map.put(55767,"riya");
map.put(47658,"priya");
for(Map.Entry<Integer, String> entry : map.entrySet())
System.out.println("key = "+entry.getKey() + "value =" + entry.getValue());
System.out.println("is key :  (19992 exist?" +  " " + map.containsKey(19992));
System.out.println("is value : neha exist?" +  " " + map.containsValue("neha"));

}
}