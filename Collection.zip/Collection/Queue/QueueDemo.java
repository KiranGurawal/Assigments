import java.util.PriorityQueue;
import java.util.Queue;
class QueueDemo
{
	public static void main(String[] args)
	{
		Queue<Integer> q=new PriorityQueue<Integer>();
		q.add(100);
		q.add(5454);
		q.add(44);
		System.out.println(q);
		System.out.println(q.poll());
		System.out.println(q.peek());
		q.remove();
		System.out.println(q);
	}
}