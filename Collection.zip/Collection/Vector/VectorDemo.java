import java.util.Vector;
import java.util.Iterator;
class VectorDemo{
	public static void main(String[] args)
	{
        Vector<Integer> v=new Vector<>();
        v.add(10);
        v.add(20);
        v.add(30);
        System.out.println(v);	
        Iterator i=v.iterator();
        while(i.hasNext())
		{
          System.out.println(i.next());
        }		  
		v.removeElementAt(2);
		System.out.println(v);
	}
}