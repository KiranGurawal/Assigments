import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Iterator;
import java.util.ArrayList;
class MapAssigment4
{

   public void saveCountryCapital(String countryName,String capital,Map s)
   {
      s.put(countryName,capital);
   }
   
   public void getCapital(String countryName,Map s)
   {
 
            Iterator<Entry<String,String>> i = s.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		   Map.Entry<String,String> m = (Map.Entry<String,String>) i.next();
 
            if(m.getKey().equals(countryName))
				System.out.println(m.getValue());
	   }
            
	   
   }
   
    public void getCountry(String capitalName, Map s)
   {

     Iterator<Entry<String,String>> i = s.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry<String,String> m= (Map.Entry<String,String>) i.next();
 
            if(m.getValue().equals(capitalName))
				System.out.println(m.getKey());
	   }
	   }
   
    public void reverseMap(Map m1)
   {
 
        Map<String,String> m2 =new HashMap<String,String>();
        Iterator<Entry<String,String>> i = m1.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry<String,String> m = (Map.Entry<String,String>) i.next();
                    m2.put(m.getValue(),m.getKey());			
	   }
	   
	    Iterator<Entry<String,String>> i1 = m2.entrySet().iterator();
	   while(i1.hasNext()) 
	   {
		    Map.Entry<String,String> m3= (Map.Entry<String,String>) i1.next();
 
             System.out.println(m3.getKey() + " = " + m3.getValue());
				
	   }   
   }
   
   
    public void arrayListConversion(Map m1)
   {
     ArrayList arr=new ArrayList();
     Iterator<Entry<String,String>> i = m1.entrySet().iterator();
	   while(i.hasNext()) 
	   {
		    Map.Entry<String,String> m = (Map.Entry<String,String>)i.next();
 
           arr.add(m.getKey());
	   }
	   System.out.println(arr);
	   
	   }
   
    public static void main(String args[])
	{
	  Map<String,Integer> m1 =new HashMap<String,Integer>();
	  Scanner sc=new Scanner(System.in);
	 
	   System.out.println("Enter the country name .");
	   String cn=sc.nextLine();
	    System.out.println("Enter the capital .");
	   String c=sc.nextLine();
	    
		MapAssignment4 obj=new MapAssignment4();
		obj.saveCountryCapital(cn,c,m1);
		
		System.out.println("Enter the country name .");
	   String cn1=sc.nextLine();
	    System.out.println("Enter the capital .");
	   String c1=sc.nextLine();
		obj.saveCountryCapital(cn1,c1,m1);
	  
     System.out.println("Enter the country name whose capital you want.");	
       String a=sc.nextLine();	 
	 obj.getCapital(a,m1);
	 
	 System.out.println("Enter the capital  whose country you want.");	
       String b=sc.nextLine();	 
	 obj.getCountry(b,m1);
	  
	  obj.reverseMap(m1);
	  obj.arrayListConversion(m1);
	   
	   
	}
}