import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;
class ArraylistMonth
{
	public static void main(String[] args)
	{
		ArrayList<String> a=new ArrayList<String>();
		String add="";
		a.add("January");
		a.add("February");
		a.add("March");
		a.add("April");
		a.add("May");
		a.add("June");
		a.add("July");
		a.add("August");
		a.add("September");
		a.add("October");
		a.add("November");
		a.add("December");
		for(int i=0;i<12;i++)
		{
			add=add+a.get(i);
		}
		System.out.println(add);
		Vector<String> v=new Vector<>();
		String vadd="";
		v.add("January");
		v.add("February");
		v.add("March");
		v.add("April");
		v.add("May");
		v.add("June");
		v.add("July");
		v.add("August");
		v.add("September");
		v.add("October");
		v.add("November");
		v.add("December");
		for(int i=0;i<12;i++)
		{
			vadd=vadd+a.get(i);
		}
		System.out.println(vadd);
	}
}