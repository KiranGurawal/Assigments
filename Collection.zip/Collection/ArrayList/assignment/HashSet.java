import java.util.HashSet;
class HashSetDemo
{
	public static void main(String[] args)
	{
		HashSet <String> h=new HashSet<String>();
		h.add("Welcome");
		h.add("to");
		h.add("Yash");
		System.out.println(h);
		System.out.println(h.contains("Techno"));
		h.remove("to");
		System.out.println(h);
		System.out.println(h.size());
	}
}