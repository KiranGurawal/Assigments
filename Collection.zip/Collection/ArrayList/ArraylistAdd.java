import java.util.ArrayList;
public class ArraylistAdd
{
	public static void main(String[] args)
	{
		ArrayList<String> a=new ArrayList<>();
		String sum="";
		a.add("techno");
		a.add("yash");
		for(int i=0;i<a.size();i++)
		{
			sum=sum+a.get(i);
		}
		System.out.println(sum);
	}
}
		