import java.util.*;
class MapDemo{
public static void main(String args[]){
Map<Integer,String> map = new HashMap<Integer,String>();
map.put(1,"kiran");
map.put(2,"neha");
map.put(3,"priya");
map.put(4,"arpit");
map.put(5,"tina");
for(Map.Entry m:map.entrySet()){
System.out.println("key : " + m.getKey() + " value : " + m.getValue());
}
List<Integer> i = new ArrayList<>(map.keySet());
Collections.sort(i);
System.out.println(i);

List<String> value = new ArrayList<>(map.values());
Collections.sort(i);
System.out.println(value);

}
}
