import java.util.Map;
import java.util.HashMap;
class MapAssigment1{
public static void main(String args[]){
Map<Integer,String> map = new HashMap<Integer,String>();
map.put(1,"kiran");
map.put(4,"neha");
map.put(5,"riya");
System.out.println(map);
System.out.println("is key : 5 exist?" +  " " + map.containsKey(5));
System.out.println("is value : kiran exist?" +  " " + map.containsValue("kiran"));

}
}