import java.util.LinkedList;
import java.util.Iterator; 
class LinkedlistDemo
{
	public static void main(String[] args)
	{
      LinkedList<String> l=new LinkedList<String>();
      l.add("yash");
      l.add("Technologies");
      l.add("Welcome's");
	  l.add("You");
      System.out.println(l);	
      Iterator<String> it=l.iterator();
      while(it.hasNext())
	  {
        System.out.println(it.next());
      }		  
	}
}