class ReflectionApi{}  
  
class ReflectionDemo2{  
  void printName(Object o){  
  Class c=o.getClass();    
  System.out.println(c.getName());  
  }  
  public static void main(String args[]){  
   ReflectionApi s=new ReflectionApi();  
   
   ReflectionDemo2 r=new ReflectionDemo2();  
   r.printName(s);  
 }  
}  