import java.util.*;
class ReflectionApi
{
}
class ReflectionDemo{
public static void main(String args[])throws Exception{
Class c = Class.forName("ReflectionApi");
System.out.println(c.getName());
}
}