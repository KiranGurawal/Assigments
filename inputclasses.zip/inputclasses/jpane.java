import javax.swing.*;
class jpane{
JFrame f;
  void showBox(){
 f= new JFrame();
 JOptionPane.showMessageDialog(f,"Hello,write jPane programe"); 
 }

public static void main(String args[]){
jpane p = new jpane();
System.exit(0);

}
}