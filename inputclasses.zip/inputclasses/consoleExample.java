import java.io.Console;
class consoleExample{
public static void main(String args[]){
String s ;
char ch[];
Console c = System.console();
System.out.println("Enter your name:");
s = c.readLine();
System.out.println("Enter your password:");
ch = c.readPassword();
String s1 = String.valueOf(ch);
System.out.println("Your name "+ s+ "password"+ ch);
System.out.println("Your name "+ s+ "password"+ s1);


}
}