import java.io.*;
class bufferReaderExample{
public static void main(String args[])throws Exception{
String name;
InputStreamReader i = new InputStreamReader(System.in);
System.out.println("Enter your name");
BufferedReader  b = new BufferedReader(i);
name = b.readLine();
System.out.println("your name is:"+ name);
}
}