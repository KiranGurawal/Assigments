class swapNo{
public static void main(String args[]){
int a=10;
int b=20;
int c;
System.out.println("After swapping no:"+ a+" " +b);
c=a;
a=b;
b=c;
System.out.println("Before swapping no:"+a+" "+b);
}

}