class leapYear{
public static void main(String ags[]){
int year = 2012;
if(year%400==0 || year%4==0 && year%100!=0){
System.out.println("this year is leap year");
}
else{
System.out.println("this is not a leap year");
}
}
}
		