class PStringBuilder{  
public static void main(String args[]){  
StringBuilder s=new StringBuilder("Kiran");  
s.append("gurawal");
System.out.println(s); 
}  
}  
