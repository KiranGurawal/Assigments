class palindrom{
public static void main(String args[]){
int a=121;
int rev=0;
int temp=a;
int rem;
while(temp!=0){
rem= temp%10;
rev = rev*10+rem;
temp=temp/10;
}
if(a==rev){
System.out.println("number is palindrome");
}
else{
System.out.println("number is not palindrome");
}
}

}