class fabSeriesByRecursion{
static int a=0,b=1, c;
public static void main(String args[]){
fabSeriesByRecursion s1 = new fabSeriesByRecursion();
s1.fabcal(10);

}

void fabcal(int i){
if(i>=1){
c=a+b;
System.out.println(c);
a=b;
b=c;
fabcal(i-1);

}
}


}