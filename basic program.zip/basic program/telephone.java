
public interface telephone{
	void powerOn();
	void dial(String PhoneNo);
	void answer();
	boolean callPhone(String PhoneNo);
	boolean PhoneRinging();
}