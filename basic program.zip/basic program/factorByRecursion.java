class factorByRecursion{
static int fact=1;
public static void main(String args[]){
  
 factorByRecursion s = new factorByRecursion();
 s.factCal(3);
 System.out.println("factorial of : "+ fact);
}
void factCal(int no){
if(no>=1){
fact = fact*no;
factCal(no-1);
}
}


}