class reverseNo{
public static void main(String args[]){
int num = 12345678;
int rev=0;
int rem;
System.out.println("real no is:"+num);
while(num!=0){
rem = num%10;
rev = rev*10+rem;
num = num/10;
}
System.out.println("reverse no is:"+rev);



}


}