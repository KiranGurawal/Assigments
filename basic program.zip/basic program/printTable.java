class printTable{
public static void main(String args[]){
int a = 4;
for(int i=1;i <=a;i++)
{
  for(int j=1;j<=10;j++){
     System.out.println(i+"*" + j + "=" + i*j);

}
        System.out.println("-----Next Table-----");
}
}}