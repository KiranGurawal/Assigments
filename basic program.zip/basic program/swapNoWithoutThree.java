class swapNoWithoutThree{
public static void main(String args[]){
int a=10;
int b=30;
System.out.println("After :"+a+" "+b);
a=a+b;
b=a-b;
a=a-b;
System.out.println("Before  :"+a+" "+b);


}
}