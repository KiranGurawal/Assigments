class factor{
public static void main(String ars[]){
int fact =1;
int num=4;
for(int i=1;i<=num;i++){
fact = fact*i;
}
System.out.println("given number Factorial is:"+ fact );

}



}