class EvenOdd{
public static void main(String args[]){
//int a=24;
int a=31;
if(a%2==0){
System.out.println("number is Even");
}
else{
System.out.println("number is Odd");}

}
}