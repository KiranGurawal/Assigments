class cons{
 string name;
 int rollno;
 cons(){
   System.out.println("Default cons..")

}
 


}