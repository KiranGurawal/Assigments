import java.util.Scanner;
class calculator{
public static void main(String args[]){
double no1;
double no2;
double ans;
char op;
Scanner s1 = new Scanner(System.in);
System.out.println("Enter two no");
no1 = s1.nextDouble();
no2 = s1.nextDouble();
System.out.println("choice your operation : +,-,*,%");
op = s1.next().charAt(0);
switch(op)
{
case '+' : ans=no1+no2;
break;
case '-' : ans=no1-no2;
break;
case '*' : ans=no1*no2;
break;
case '%' : ans=no1%no2;
break;
default: System.out.println(" wrong operation ");
return;
}
System.out.println("Your ans is:");
System.out.println(no1+" "+op+" "+ no2 + "="+ ans);

}
}