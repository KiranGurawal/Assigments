class functionAdd{

public static void Add(int a, int b){
int c=a+b;
System.out.println("Addtion of two no:"+c);
}
public static void Mul(int a,int b){
int c= a*b;
System.out.println("Multiplication of two no:"+c);
}
public static void Del(int a, int b){
int c= a/b;
System.out.println("Deletion of two no:"+c);
}


public static void main(String args[]){
 Add(20,12);
 Mul(2,4);
 Del(100,2);

}



}