class demo{
public static void main(String args[]){
String s = "Kiran";
s=s.concat("Gurawal");
System.out.println(s);

}}