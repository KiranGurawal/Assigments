class basic{
void eat(){
System.out.println("i am eating");
}

public satatic void main(String args[]){
   System.out.println("Hello");
}


}