class outer{
class inner{
void show(){
System.out.println("outer show");
}
}
}
public class outerDemo{
public static void main(String args[]){
outer o = new outer();
outer.inner oi = o.new inner();
oi.show();
}

}