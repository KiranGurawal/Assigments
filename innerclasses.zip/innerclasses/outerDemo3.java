class outer{
static void show(){
System.out.println("outer class call");
}
 static class inner{
 void show(){
System.out.println("inner class call");
}

}
}
class outerDemo3{
public static void main(String args[]){
outer.inner o = new outer.inner();
o.show();

}

}