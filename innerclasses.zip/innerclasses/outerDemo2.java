class outer{
void show(){
System.out.println("outer class call");
}
 static class inner{
show();
}
}
class outerDemo2{
public static void main(String args[]){
outer.inner o = new outer.inner();
o.show();

}

}