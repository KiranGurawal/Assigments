class outer{
 class inner{
 void show(){
System.out.println("i am static class");
}
}
class inner2{
void show(){
	System.out.println("i am in non static class");
}
}
}
class InnerDemo{
public static void main(String args[]){
outer.inner o = new outer.inner();
o.show();
outer oi = new outer();
outer.inner2 i =oi.new inner2();
i.show();
}

}