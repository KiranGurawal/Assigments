class outer{
static int a=10;
static int b=20;
}
static class inner{
System.out.print(a);
}
class outerDemo4{
public static void main(String args[]){
outer.inner o = new outer.inner();
}

}