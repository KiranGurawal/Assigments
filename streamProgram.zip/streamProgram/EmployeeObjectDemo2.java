import java.io.*;
class Employee{
int empId;
String empname;
Employee(int empId, String empname){
	this.empId = empId;
	this.empname = empname;
}
public String toString(){
	return empId + " "+empname;
}
}
class EmployeeObjectDemo2{
	public static void main(String args[]) throws Exception{
		Employee e = new Employee(21,"Kiran");
		System.out.println(e);
		File f = new File("d:\\Yash.txt");
		ObjectOutputStream ois = new ObjectOutputStream(new FileOutputStream(f));
		ois.writeObject(e);
		ois.close();
		
}
	}