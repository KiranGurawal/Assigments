import java.io.File;
import java.io.FileReader;
class IoStreamAssigment2{
public static void main(String args[]) throws Exception{
int a = 0;
int e = 0;
int i = 0;
int o = 0;
int u = 0;

FileReader in = new FileReader("D:\\Yash.txt");
int vowel;
while((vowel = in.read()) != -1){
char c =(char)vowel;
if(c == 'a' || c=='A'){
	a++;
}
if(c == 'e' || c=='E'){
	e++;
}
if(c == 'i' || c=='I'){
	i++;
}
if(c == 'o' || c=='O'){
	o++;
}
if(c == 'u' || c=='U'){
	u++;
}
}
System.out.println("no of a:" +a);
System.out.println("no of e:" +e);
System.out.println("no of i:" +i);
System.out.println("no of o:" +o);
System.out.println("no of u:" +u);

}

}