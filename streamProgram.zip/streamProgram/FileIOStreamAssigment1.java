import java.io.*;
/*import java.io.FileInputStream;
import java.io.FileInputStreamReader;
import java.io.BufferedOutReader;*/
class FileIOStreamAssigment1{
public static void main(String args[]) throws IOException{
File f = new File("d:\\Yash.txt");
FileInputStream input = new FileInputStream(f);
InputStreamReader reader = new InputStreamReader(input);
BufferedReader b = new BufferedReader(reader);
	String line;
	int wordCount = 0;
	int character = 0;
	int space = 0;
	int paraCount = 0;
	int NoLine =0;

	
  	while((line = b.readLine()) !=null) {
	if(line.equals("")){
		paraCount += 1;
	}
	else{
	character +=line.length();
	String w[] = line.split("\\s+");
	wordCount += w.length;
	space +=wordCount - 1;
	String sentence[] = line.split("[!?.:]+");
	NoLine += sentence.length;
	}

}
	if(NoLine >=1){
	paraCount++;
	}

	System.out.println("Total no words :"+wordCount);
	System.out.println("Total no of lines "+ NoLine);
	System.out.println("Total no of character :"+character);	
	System.out.println("Total no of space :"+space);

}
}