import java.io.File;
import java.io.FileWriter;
import java.io.IOExpection;
import java.io.FileReader;
class streamDemo{
public static void main(String args[]) throws IOException
	{
		File f = new File("D:/Yash/abc.txt");
                 f.CreateNewFile();
		// System.out.println(f.exists);
		FileWriter w = new FileWriter(f);
                w.writer("welocme to Fullstack Developer Course");
			w.close();
		FileReader r = new FileReader(f);
		char a[]= new char[20];
			r.read(a);
			for(char c:a)
				System.out.print(c);
				r.close();
}
}