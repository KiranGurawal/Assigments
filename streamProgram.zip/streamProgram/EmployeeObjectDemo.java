import java.io.*;
class Employee implements Serializable{
int empId;
String empname;
Employee(int empId, String empname){
	this.empId = empId;
	this.empname = empname;
}
public String toString(){
	return empId + " "+empname;
}
}
class EmployeeObjectDemo{
	public static void main(String args[]) throws Exception{
		Employee e = new Employee(21,"Kiran");
		
		File f = new File("d:\\Yash.txt");
	        f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee e1 =(Employee)ois.readObject();
		ois.close();
		System.out.println(e1);
	}
}
