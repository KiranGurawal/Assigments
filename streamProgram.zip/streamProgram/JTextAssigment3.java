import java.io.*;
import java.util.Scanner;
class JTextAssigment3{
public static void main(String args[]){
Scanner s1 =new Scanner(System.in);
String file = "D:\\Yash.txt";
String line = "";
	try{
	while(s1.hasNextLine()){
		line = s1.nextLine();
		int counter = 0;
		for(int i=0; i<line.length(); i++)
		{
			if(line.charAt(i) == 'j')
			{
				counter++;
			}
		}
			System.out.println(counter);
				}
	}
		finally{
		s1.close();
}
}

}