package com.yash.beanpost;

public class TestBean {
	public TestBean(){
	System.out.println("TestBean is created.");
	}
	}