package com.yash.springjdbc.dao;

import com.yash.springjdbc.entities.Employee;

public interface EmployeeDao {

	public int insert(Employee e);
	//public int updatedetails(Employee e);
	//public int deletedetails(String empename);
}
