package com.yash.springjdbc.dao;
import com.yash.springjdbc.entities.*;
import org.springframework.jdbc.core.JdbcTemplate;


public class EmployeeDaoImpl implements EmployeeDao {

private JdbcTemplate jdbctemp;


public int insert(Employee e) {

String q="insert into employee(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
int msg=this.jdbctemp.update(q,e.getEmpname(),e.getEmailid(),e.getDob(),e.getContactno(),e.getSalary());
return msg;
}
public JdbcTemplate getJdbctemp() {
return jdbctemp;
}
public void setJdbctemp(JdbcTemplate jdbctemp) {
this.jdbctemp = jdbctemp;
}
	public int updatedetails(Employee e) {
		// update details of employee
		String q="update employee set contactno=? where empname=?";
		int msg=this.jdbctemp.update(q,e.getContactno(),e.getEmpname());
		return msg;
}
	public int deletedetails(String empename) {
		// TODO Auto-generated method stub
		String q="delete from employee where empname=?";
		int msg=this.jdbctemp.update(q,empename);
		return 0;
	}



}
