package com.yash.springORMAssignment;

/**
 * Hello world!
 *
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.yash.springORMAssignment.dao.StudentDao;
import com.yash.springORMAssignment.entities.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDao studao = context.getBean("studentDao", StudentDao.class);
		Student stu = new Student(3, "kiran");
		//int msg = studao.insert(stu);
		//System.out.println(msg + "insertion done");
		System.out.println( studao.getStudentDetails(2));
		//System.out.println( studao.getAllStudents());
		// studao.deleteDetails(3);
		System.out.println(studao.updateDetails(kiran));

	}
}
