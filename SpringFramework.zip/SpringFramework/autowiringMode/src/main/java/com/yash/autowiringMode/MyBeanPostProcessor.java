package com.yash.autowiringMode;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class MyBeanPostProcessor implements BeanPostProcessor {
  public Object postProcessAfterInitialization(Object object, String string)throws BeansException{
	 System.out.println("AfterInitialization"+ string);
	 return object;
  }	
  public Object postProcessBeforeInitialization(Object object, String string)throws BeansException{
		 System.out.println("BeforeInitialization"+ string);
		 return object;
	  }	
}
