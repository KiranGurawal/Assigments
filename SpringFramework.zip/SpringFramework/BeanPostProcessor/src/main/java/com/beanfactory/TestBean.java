package com.beanfactory;

public class TestBean {
	public TestBean(){
		System.out.println("TestBean is created.");
	}

}
