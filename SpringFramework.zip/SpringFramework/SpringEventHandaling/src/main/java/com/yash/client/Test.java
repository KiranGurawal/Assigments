package com.yash.client;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.SpringEventHandaling.Message;

public class Test 
{

	public static void main(String[] args) 
	{
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		
		ctx.start();
		
		Message message = ctx.getBean("message", Message.class);
	
		
		System.out.println(message.getMessageId()+"\t"+message.getMessage());
		
		System.out.println("---------------------------------------------------------------------------------");
		
		ctx.stop();
		
		ctx.close();

	}

}
