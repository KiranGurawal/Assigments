package com.yash.event.handler;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;

public class ContextStoppedEventHandaler implements ApplicationListener<ContextStoppedEvent>
{

	public void onApplicationEvent(ContextStoppedEvent cse) 
	{
		System.out.println("ContextStoppedEvent Received..");
		
		//ApplicationContext applicationContext = cse.getAplicationContext();
		System.out.println(cse.getSource());
		
		System.out.println("--------------------------------------------------------------------------------------------");
		
	}
}
