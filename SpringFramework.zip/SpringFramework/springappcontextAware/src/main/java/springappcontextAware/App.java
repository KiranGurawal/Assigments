package springappcontextAware;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("HOLA EMPLOYEES!");
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		TestAware test = (TestAware) context.getBean("awareappcontext");
		ApplicationContext appcontext = test.getContext();
		Employee e = (Employee) appcontext.getBean("emp");
		System.out.println(e);
		

	}

}
