package com.auto.wire;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;

public class Emp {
	@Resource(name="address")
	private Address address;
	private Address address2;

	public Emp(Address address) {
		super();
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Emp [address=" + address + "]";
	}
	
	
}
