package com.auto.wire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	
	public static void main(String[] args) {
	System.out.println("AutoWire");

	ApplicationContext context = new  ClassPathXmlApplicationContext("com/auto/wire/applicationcontext.xml");
	Emp emp= context.getBean("emp", Emp.class);
	System.out.println(emp);

	}
}
	