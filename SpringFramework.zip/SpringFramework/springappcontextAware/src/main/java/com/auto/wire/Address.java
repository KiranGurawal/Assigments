package com.auto.wire;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Address implements ApplicationContextAware,BeanNameAware{
	private String Street;
	private String pincode;
	private ApplicationContext context =null;

	public String getStreet() {
		return Street;
	}

	public void setStreet(String street) {
		Street = street;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [Street=" + Street + ", pincode=" + pincode + "]";
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.context= context;
		
	}

	public void setBeanName(String name) {
		System.out.println("Bean name is: ");
		
	}

	
}
