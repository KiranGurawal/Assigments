package com.springcore.lifecycle;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Annotation {
private String type;

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

@Override
public String toString() {
	return "Car [type=" + type + "]";
}

public Annotation() {
	super();

}
@PostConstruct
public void init() {
	System.out.println("this is a annotation init method");
	
}
@PreDestroy
public void end()
{
	System.out.println("end of annotation");
}
}
