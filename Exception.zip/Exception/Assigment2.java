import java.util.Scanner;
class Assigment2{
public static void main(String args[]){

try{
int array[] = new int[4];
Scanner s = new Scanner(System.in);
System.out.println("Inter the array value");
for(int i=0;i<=array.length;i++){
array[i]=Integer.parseInt(s.next());
}
System.out.println("Enter the index of the array you want to access");
int i = s.nextInt();
System.out.println("The array element at index" +i+ "=" +array[i]);
System.out.println("The array element successfully accessed");
}

catch(Exception e){
System.out.println(e);
}
}
}