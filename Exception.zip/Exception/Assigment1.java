import java.util.Scanner;
class Assigment1{
public static void main(String args[]){
Scanner s = new Scanner(System.in);
System.out.println("Enter a Integer");
try{
int a = s.nextInt();
int square = a*a;
System.out.println(square);
}
catch(Exception e){
System.out.println("Enter input is not a valid format for an Integer");
}
}


}