class ExceptionDemo1{
public static void main(String args[]){
String s = null;
System.out.print(s.length());


}
}