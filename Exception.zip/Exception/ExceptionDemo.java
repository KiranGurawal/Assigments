class ExceptionDemo{
public static void main(String args[]){
System.out.println("hello");
System.out.println("this is Arthimatic Exception");
System.out.println(25/0);

}
}