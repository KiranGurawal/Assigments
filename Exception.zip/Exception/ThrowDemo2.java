import java.util.Scanner;
class ArithmeticExp extends RuntimeException{
ArithmeticExp(String e){
super(e);
}
}

class ThrowDemo2{
public static void main(String args[])
{
Scanner s = new Scanner(System.in);
System.out.println("Enter a and b:");
int a = s.nextInt();
int b = s.nextInt();
try{
int c = a/b;
   System.out.println("The quotient of a/b = "+c);
}
catch(ArithmeticExp e){
System.out.println("DivideByZeroException");
}
finally{
System.out.println("Inside finally block");
}
}
}