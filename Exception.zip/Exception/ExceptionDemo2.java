import java.io.FileInputStream;
class ExceptionDemo2{
public static void main(String args[]){
//FileInputStream s = new FileInputStream("c://programe");// file not found
try{
FileInputStream t = new FileInputStream("c://programe");
}
catch(Exception e){
System.out.print(e);
}

}
}