import java.lang.ClassNotFoundException;
class ThrowsD{
void show()throws ClassNotFoundException{
Class.forName("mssqlserverjdbc/Driver/sqljdbc_8.4/enu");
}
}

class ThrowsExample{
public static void main(String args[]){
ThrowsD t = new ThrowsD();
try{
t.show();
}
catch(ClassNotFoundException c){
c.printStackTrace();
}
System.out.print("normal terminated");

}
}