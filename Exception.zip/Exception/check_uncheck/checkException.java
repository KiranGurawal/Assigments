import java.io.*;
import java.io.IOException;
class checkException{
public static void main(String args[])throws Exception{
	File f = new File("");
	try{
	//FileInputStream s = new FileInputStream(f);
	Class.forName("jdbc:\\driver.mysqlDriver");
	}
	//catch(FileNotFoundException e){
	//e.printStackTrace();
	//}
	catch(ClassNotFoundException e1){
	e1.printStackTrace();
	}
	finally{
	System.out.println("this is checked exception");
}
       
}

}