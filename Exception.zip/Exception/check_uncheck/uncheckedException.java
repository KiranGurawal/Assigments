class uncheckedException{
public static void main(String args[]){
int a = 10;
int b = 0;
int array[] = {10,20,30,40} ;
String name = null;
String exp = "123.4";
try{
int c =10/0;   // arthimatic 
System.out.println(c);
System.out.println(array[6]);     // arrayIndexOfBound exception
if("Kiran".equals(name)){
	System.out.println("String same");
}
else{
	System.out.println("not same");
}
int a1 = Integer.parseInt(exp);
}
catch(ArithmeticException e){
	System.out.println("its arthimatic exception occuer");
}
catch(NullPointerException e1){
	System.out.println("its nullpointer exception");

}
catch(ArrayIndexOutOfBoundsException e2)
{
	System.out.println("its arrayindexof bound");
}
catch(NumberFormatException e3)
{
	System.out.println("invalid string");
}
}
}