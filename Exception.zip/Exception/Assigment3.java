import
class Assigment3{
public static void main(String args){


}
}