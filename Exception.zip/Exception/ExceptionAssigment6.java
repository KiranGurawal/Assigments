import java.util.Scanner;
class NegativeValueException extends RuntimeException{
 NegativeValueException(String s){
 	super(s);
}
}
class OutOfRange extends RuntimeException{
OutOfRange(String s){
  super(s);
}
}

class ExceptionAssignment6{
public static void main(String args[]){
Scanner s = new Scanner(System.in);
int a[]= new int[3];
int b[]= new int[3];
int sum1=0;
int sum=0;
System.out.println("Enter name of the student1 and student2");
String s1 = s.nextLine();
String s2 = s.nextLine();
try{
for(int i =0;i<3;i++){
System.out.println("Enter your mark both s1 ams s2");
a[i]=Integer.parseInt(s.next());
b[i]=Integer.parseInt(s.next());
if(a[i]<0 || b[i]<0){
throw new NegativeValueException("you have entered Negative Value");
}
else if(a[i]>100 || b[i]>100){
throw new OutOfRange("You have enter values OutofRange");
}
else{

}}
int avg = sum/3;
int avg2 = sum1/3;
System.out.println("name of student" + s1 +" "+s2);
System.out.println("Average marks of student1 and student2" +avg+" "+avg);
}
catch(NegativeValueException n){
 n.printStackTrace();

}
catch(OutOfRange o){
 o.printStackTrace();

}

}

}