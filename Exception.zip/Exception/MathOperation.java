import java.util.Scanner;
class MathOperation{
public static void main(String args[]){
int sum=0;
try{
System.out.println("Enter array size"); 
Scanner s = new Scanner(System.in);
int n = s.nextInt();
int array[]=new int[n];
for(int i=0;i<array.length;i++){
        array[i] = Integer.parseInt(s.next());  

sum = sum+array[i];
}
int avg = sum/n;
System.out.print("sum of array:" + sum);
System.out.print("average of number" + avg);
}
catch(ArrayIndexOutOfBoundsException e){
System.out.println("java.lang.(ArrayIndexOutOfBoundsException occure");
}
catch(NumberFormatException NE){
System.out.println("NumberFormatException");
}
}
}