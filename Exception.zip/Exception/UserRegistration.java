import java.util.Scanner;
class InvalidCountryException extends RuntimeException{
InvalidCountryException(String s)
{
    super(s);
}

}

class UserRegistration{
void registerUser(String name,String usercountry){
try{
if(usercountry.equals("India")){
System.out.println("You are Successfully registered");
}
else{
throw new InvalidCountryException("User outside India cannot be registered");
}
}
finally{

System.out.println("Bye...!");
}}
public static void main(String args[]){
UserRegistration r = new UserRegistration();
Scanner s = new Scanner(System.in);
System.out.println("Enter your username and country ");
String uname = s.nextLine();
String cname = s.nextLine();
r.registerUser(uname,cname);
}



}

