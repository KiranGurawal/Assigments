class ExceptionDemo4{
public static void main(String args[]){
int a=10;
int b=0;
int c;
try{
c= a/b;
}
catch(Exception e){
//e.printStackTrace();
//System.out.println(e);
System.out.println(e.getMessage());
}
finally{
System.out.println("i am finally block");

}
}
}