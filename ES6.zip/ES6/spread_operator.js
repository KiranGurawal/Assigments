var arr1=[2,4,6];
var arr2=[3,5,7];
var comarr=[...arr1,...arr2];
console.log(comarr);

var arr3=[2,3,56,6,76,54,3,2,656,];
var[f,s,r,e,...rem]=arr3;
console.log(f);
console.log(s);
console.log(r);
console.log(e);
console.log(rem);