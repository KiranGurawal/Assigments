var studentdetails={
	sname: "Harshita Rathore",
	roll: 99,
	dept: "Computer Science",
	College: "Medi-Caps University",
};
function printSD({sname,roll,dept,College})
	{
		console.log(sname);
		console.log(roll);
		console.log(dept);
		console.log(College);
	}
	printSD(studentdetails);