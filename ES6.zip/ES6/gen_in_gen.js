function * gen1()
{
	yield 2;
	yield 4;
}
function * gen2()
{
	yield 'a';
	yield * gen1();
	yield 'b';
}
for(let v of gen2())
{
	console.log(v);
}