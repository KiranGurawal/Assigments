var a=10;
console.log(a);
var b=12;
var b=23;
console.log(b);