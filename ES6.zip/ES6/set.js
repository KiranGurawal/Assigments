const names= new Set(["harshita","Mohit","Aditi","Ishika"]);
console.log(names.size);
names.add("Kartik");
console.log(names.size);
for(let x of names.values())
	console.log(x);
names.delete("Kartik");
console.log(names.size);
for(let x of names.values())
	console.log(x);