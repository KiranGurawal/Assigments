class Demo
{
	constructor(x,y)
	{
		this.x=x;
		this.y=y;
	}
	show()
	{
		console.log("value of x: "+this.x);
		console.log("value of y: "+this.y);
	}
}
let obj= new Demo(12,10);
obj.show();

class s1
{
	static show()
	{
		console.log("This is static function");
	}
}
s1.show();