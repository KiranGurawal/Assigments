var x=(a,b)=> a+b;
console.log("Sum is: "+x(12,12));
 
var m= a=>("this is value of ") +a;

console.log(m("Harshita"));
console.log(m(1429));