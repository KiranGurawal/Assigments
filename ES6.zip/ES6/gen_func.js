function * gen()
{
	yield 5;
	yield 10;
	yield 15;
}
var x=gen();
var a=x.next().value;
console.log("first value: "+a);
for(let i=1;i<=a;i+=2)
{
	console.log(i);
}
console.log("second value which is generated:-"+x.next().value);
console.log("Third value which is generated:-"+x.next().value);