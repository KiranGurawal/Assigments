setInterval(fun1,1000);
setInterval(show,500);
function fun1()
{
	console.log("fun1 is calling after 1 second");
}
function show()
{
	console.log("show is calling after .5 seconds");
}