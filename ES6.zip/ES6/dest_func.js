function area()
{
  let circle=3.14*6*6;
  let square=10*10;
   return [circle,square];  
}
var [cir1,sq1]=area();
console.log("Area of circle: " +cir1);
console.log("Area of square: "+sq1);