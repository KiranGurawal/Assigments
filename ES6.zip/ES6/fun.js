function show()
{
	console.log("This is show function");
}
show();
var x=function(a,b)
{
	 console.log(a+b);
}
x(10,10);