const marks = new Map([["harshita",10],["Ishika",9]]);
console.log(marks.get("harshita"));
marks.set("Aditi",8);
marks.forEach(function(value,key){
  console.log("key: " +key+" value:"+value);	
});
if(marks.has("harshita"))
	console.log("harshita exist");
else
	console.log("doesn't exist");