var choco = ['munch','kitkat','perk'];
var [chocho1,chocho2,chocho3]=choco;
console.log(chocho2);
console.log(chocho3);
var [car11,,car14]= choco;
console.log(car11);
console.log(car14);