class first{
public static void main(){
System.out.println("Hello");
}

}