class Arrayj{
public static void main(String args[]){
int [][]a = new int[2][];
a[0]=new int[3];
a[1]= new int[2];
a[2]= new int[3];
System.out.print(a);
//System.out.print(a[0]);
//System.out.print(a.length);

}

}