class Swap{
public static void main(){
int a=10;
int b=20;
int c;
c=a;
a=b;
a=c;
System.out.println(" Before swapping"+a" "b)

}
}