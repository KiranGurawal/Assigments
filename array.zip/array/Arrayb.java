import java. util. *;
class Arrayb{
public static void main ( String args [] )
{
Scanner s1 = new Scanner(System.in );
int i, k=0;
int a [] = {1,4,1,4};
for( i=0;i<a.length;i++)
{
System.out.println ( a[ i ] + " " ) ;
}
for( i=0;i<a.length;i++)
{
if( a [ i ] == 1 || a [ i ] == 4 )
k++;
}
if( k == a.length )
System.out.println(" True ");
else
System.out.println(" False ");
}
}

