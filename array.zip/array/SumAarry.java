class SumAarry{
public static void main(String args[]){
int array[]={10,20,30,40};
int sum=0;
System.out.println("Array list:"+array);
for(int i=0;i<array.length;i++){
sum=sum+array[i];
}
System.out.println(sum);
int avg = sum/4;
System.out.println(avg);

}
}