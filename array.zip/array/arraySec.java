class arraySec{


}