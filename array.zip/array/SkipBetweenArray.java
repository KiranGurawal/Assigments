class SkipBetweenArray
{
	public static void main(String [] args)
	{
		int[] array=new int[]{1,2,3,4,5,6,1,2,3,4,12,24,7,8,9};
		int sum=0;
		for(int a=0;a<array.length;a++)
		{
			if(array[a]==6)
			{
				for(int b=a+1;b<array.length;b++)
				{
					if(array[b]!=7)
					{
						array[b]=0;
					}
					else
					{
						break;
					}
				}
			}
		}
		for(int c:array)
		{
			sum=sum+c;
		}
		System.out.println(sum);
	}
}