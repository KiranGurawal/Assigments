class EvenOdd{
public static void main(){

int a=10;
System.out.println("a");
if(a%2==0){
System.out.println("the number is even");

}
else{
system.out.println("the number is odd");
}
}
}