class array3D{
public static void main(String args[]){
int max = 0;
int a = args.length;
int i;
int arr[][]=new int[3][3];
if(a<9){
System.out.println("enter nine values");
}
if(a==9){
int k=0;
for(i=0;i<3;i++){
for(int j=0;j<3;j++){
arr[i][j]= Interger.parseInt(args[k]);
k++;
}
}
System.out.println("the given array is:");
for(int j=0;j<3;j++){
System.out.print(arr[i][j]+ " ");
}
System.out.println();
}
for(i=0;i<3;i++){
  for(int j=0;j<3;j++){
	if(max<arr[i][j])
		max=arr[i][j];

}
     System.out.println("the biggest number is" + max);

}

}
}