class sortArray{
public static void main(String args[]){
int array[]={5,7,12,43,48};
int num=0;
for(int i=0; i<array.length;i++){
if(array[i]>num)
num=array[i];
System.out.println(num);
}
}
}