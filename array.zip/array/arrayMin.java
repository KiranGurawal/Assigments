class arrayMin{
public static void main(String args[]){
int array[]={20,45,76,71,4};
int min=array[0];
for(int i=0; i<array.length;i++){
if(array[i]<min){
min=array[i];
}
}
System.out.println(min);
}
}