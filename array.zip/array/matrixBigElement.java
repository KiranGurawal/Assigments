class matrixBigElement{
      final static int X = 3;
      final static int Y = 3 ;
      static int findMax(int mat[][])
    {
        int maxElement = Integer.MIN_VALUE;
 
        for (int i = 0; i < X; i++) {
            for (int j = 0; j < Y; j++) {
                if (mat[i][j] > maxElement) {
                    maxElement = mat[i][j];
                }
            }
        }
        return maxElement;
    }
    public static void main(String args[])
    {
        int mat[][] = { { 1, 23, 24},
                          {77, 67, 90},
                          { 110, 222, 121 }};
        System.out.println(findMax(mat)) ;
   
    }
}
