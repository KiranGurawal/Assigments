class swap1{
public static void main(){
int a=10;
int b=20;
Syatem.out.println("")


}
}