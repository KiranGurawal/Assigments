import About from './view/Home';
import Home from './view/About';
import './App.css';
import { Component } from 'react';
import React from 'react';
import { BrowserRouter as Router,Routes, Route, Link } from 'react-router-dom';



class App extends Component{
  render(){
  return (
 <Router>
 <div className="App">
 <ul >
<li>
<Link className="App-header" to="/">Home</Link>
</li>
<li>
 <Link className="App-header" to="/about">About Us</Link>
</li>
</ul>
<Routes>
<Route exact path='/' element={< Home />}></Route>
<Route exact path='/about' element={< About />}></Route>
</Routes>
</div>
</Router>


  );
}
}

export default App;
