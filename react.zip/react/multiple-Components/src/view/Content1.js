import React, {Component} from 'react';

class Content1 extends React.Component

{

render()

{

    return(

        <div>

            <h1>Yash Technologies</h1>
            <p>YASH Technologies is a leading technology integrator specializing in helping clients reimagine operating models, enhance competitiveness, optimize costs, foster exceptional stakeholder experiences and drive business transformation. With our unique 'glocal' approach, we consultatively partner clients across geographies as a robust local provider while allowing them to take advantage of our market-leading portfolio of technology services, solutions, and products; globally. As a 'Partner of Choice' for 75 Fortune500 corporations, we foster long-term strategic relationships with clients across Manufacturing, Lifesciences, BFSI, 
              
                </p>

        </div>

    );

}



}

export default Content1;