import React, {Component} from 'react';

class Queryform extends React.Component

{

render()

{

    return(

        <div>

            <h1>QueryForm</h1>
            <fieldset>
            <form>
                
            <label> Firstname </label>
            <input type="text" name="firstname" size="15"/> 
            <label> Middlename: </label>
            <input type="text" name="middlename" size="15"/>  
            <label> Lastname: </label>
            <input type="text" name="lastname" size="15"/> 
            <br></br>
            <input type="button" value="Submit"/>
            </form>
            </fieldset>

        </div>

    );

}



}

export default Queryform;