import React, {Component} from 'react';



class Content2 extends React.Component

{

render()

{

    return(

        <div>

            <h1>Conetent2</h1>
            <p>
             hello yashIan
             
            </p>

        </div>

    );

}



}

export default Content2;