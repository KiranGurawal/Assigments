import React, {Component} from 'react';

class Navigation extends React.Component

{

render()

{

    return(

        <div>

            <h1>Navigation</h1>
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="contactus.html">Aboutus</a></li>
                <li><a href="service.html">Service</a></li>
                <li><a href="contactus.html">Contactus</a></li>
                </ul>

        </div>

    );

}



}

export default Navigation;