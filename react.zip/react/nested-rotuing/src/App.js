import {BrowserRouter as Router, Link, Routes, Route} from 'react-router-dom';
import Home from './views/Home';
import Services from './views/Services';
import Software from './views/Software';
import Webd from './views/Webd';
import './App.css';

function App() {
  return (
    <div className="App">
      <Router>
        <nav>
          <Link to="/">Home</Link>
          <Link to="services">Services</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />}>
            <Route path="software" element={<Software />} />
            <Route path="webd" element={<Webd/>}/>
          </Route>
        </Routes>
     </Router>
    </div>
  );
}

export default App;
