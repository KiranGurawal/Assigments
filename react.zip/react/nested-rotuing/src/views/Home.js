import React,{Component} from "react";
class Home extends Component{
    render()
    {
        return(
            <div className="home">
                <img src="https://th.bing.com/th/id/OIP.ewoqqugTxEWaNfWEEoM0swHaEo?pid=ImgDet&rs=1"></img>
                <div>
                    <form>
                        Name:<input type="text"/><br></br>
                        email:<input type="email"/><br></br>
                        <input type="submit" value="submit"/>
                    </form>
                </div>
            </div>
        );
    }
}
export default Home