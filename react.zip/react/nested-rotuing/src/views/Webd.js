import React,{Component} from "react";
class Webd extends Component
{
    render()
    {
        return(
            <div className="webd">
                <p>Providing solutions through website development</p>
                <img src="https://th.bing.com/th/id/OIP.35OVADhbSdUAn3IORj0mgQHaEo?w=295&h=184&c=7&r=0&o=5&dpr=1.5&pid=1.7"></img>
            </div>
        );
    }
}
export default Webd