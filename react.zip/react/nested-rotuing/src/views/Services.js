import React,{Component} from "react";
import { Link, Outlet } from 'react-router-dom'
class Services extends Component
{
    render()
    {
        return(
            <div className="services">
                <p>Here the services of website are listed</p>
                <div className="services-nav">
        <Link to="/services/software">Software</Link>
        <Link to="/services/webd">Web Development</Link>
      </div>
      <Outlet />
            </div>
        );
    }
}
export default Services