import React,{Component} from "react";
class Software extends Component
{
    render()
    {
        return(
            <div className="software">
                <img src="https://th.bing.com/th/id/OIP.t8cxiVWf7fXdKmrQyXnzmwHaEK?w=321&h=181&c=7&r=0&o=5&dpr=1.5&pid=1.7"></img>
            </div>
        );
    }
}
export default Software